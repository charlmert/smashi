import getpass

def get_username():
    return getpass.getuser()
